package com.claudepage.app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Icon
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", 0L)
        val nid = (id and 0x7fffffffL).toInt()
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val action = i.action
        if (action == "com.claudepage.DONE") {
            Store.finish(c, id)
            nm.cancel(nid)
            return
        }
        if (action == "com.claudepage.SNOOZE") {
            Store.snooze(c, id)
            nm.cancel(nid)
            return
        }
        Notifier.channel(c)
        val l = Store.reminders(c)
        val r = l.find { it.id == id }
        val text = r?.text ?: (i.getStringExtra("text") ?: "Reminder")
        if (r != null && r.repeat > 0) {
            Alarms.advance(r)
            Alarms.set(c, r)
            Store.saveReminders(c, l)
        } else {
            Widgets.refresh(c)
        }
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val done = actionFor(c, "com.claudepage.DONE", "Done", id, nid / 4 + 1)
        val snooze = actionFor(c, "com.claudepage.SNOOZE", "Snooze 10 min", id, nid / 4 + 2)
        val n = Notification.Builder(c, Notifier.CH)
            .setSmallIcon(R.drawable.ic_burst)
            .setContentTitle("Reminder")
            .setContentText(text)
            .setColor(0xFFD97757.toInt())
            .setCategory(Notification.CATEGORY_REMINDER)
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(done)
            .addAction(snooze)
            .build()
        nm.notify(nid, n)
    }

    private fun actionFor(c: Context, action: String, label: String, id: Long, code: Int): Notification.Action {
        val pi = PendingIntent.getBroadcast(c, code,
            Intent(c, ReminderReceiver::class.java).setAction(action).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_burst), label, pi).build()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val l = Store.reminders(c)
        l.forEach {
            Alarms.advance(it)
            Alarms.set(c, it)
        }
        Store.saveReminders(c, l)
    }
}

abstract class BaseWidget : AppWidgetProvider() {
    open val layout: Int get() = R.layout.widget_card
    abstract fun fill(c: Context, v: RemoteViews)

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(c.packageName, layout)
            val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            v.setOnClickPendingIntent(R.id.root, pi)
            fill(c, v)
            m.updateAppWidget(id, v)
        }
    }
}

class NextWidget : BaseWidget() {
    override fun fill(c: Context, v: RemoteViews) {
        val now = System.currentTimeMillis()
        val r = Store.reminders(c).filter { !it.done && it.time > now }.minByOrNull { it.time }
        v.setTextViewText(R.id.w_label, "Next reminder")
        v.setTextViewText(R.id.w_title, r?.text ?: "Nothing coming up")
        v.setTextViewText(R.id.w_body, if (r != null) fmt(r.time) else "Open Claude Page to add one")
    }
}

class NoteWidget : BaseWidget() {
    override fun fill(c: Context, v: RemoteViews) {
        val n = Store.notes(c).maxByOrNull { it.updated }
        v.setTextViewText(R.id.w_label, "Latest note")
        v.setTextViewText(R.id.w_title, n?.title?.ifBlank { "Untitled" } ?: "No notes yet")
        v.setTextViewText(R.id.w_body, n?.body ?: "Open Claude Page to write one")
    }
}

class AgendaWidget : BaseWidget() {
    override fun fill(c: Context, v: RemoteViews) {
        val now = System.currentTimeMillis()
        val rs = Store.reminders(c).filter { !it.done && sameDay(it.time, now) }.sortedBy { it.time }
        val f = SimpleDateFormat("HH:mm", Locale.getDefault())
        v.setTextViewText(R.id.w_label, "Today")
        v.setTextViewText(R.id.w_title,
            if (rs.isEmpty()) "Nothing planned" else rs.size.toString() + (if (rs.size == 1) " reminder" else " reminders"))
        v.setTextViewText(R.id.w_body, rs.take(5).joinToString("\n") { f.format(Date(it.time)) + "   " + it.text })
    }
}

class CalendarWidget : BaseWidget() {
    override val layout: Int get() = R.layout.widget_calendar

    override fun fill(c: Context, v: RemoteViews) {
        val now = Calendar.getInstance()
        v.setTextViewText(R.id.cal_title, SimpleDateFormat("LLLL yyyy", Locale.getDefault()).format(now.time))
        val first = now.clone() as Calendar
        first.set(Calendar.DAY_OF_MONTH, 1)
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val days = first.getActualMaximum(Calendar.DAY_OF_MONTH)
        val rs = Store.reminders(c).filter { !it.done }
        val ink = c.getColor(R.color.ink)
        val acc = c.getColor(R.color.accent)
        for (i in 0 until 42) {
            val id = c.resources.getIdentifier("c" + i, "id", c.packageName)
            val day = i - offset + 1
            if (day in 1..days) {
                v.setTextViewText(id, day.toString())
                val has = rs.any {
                    val x = Calendar.getInstance()
                    x.timeInMillis = it.time
                    x.get(Calendar.YEAR) == now.get(Calendar.YEAR) && x.get(Calendar.MONTH) == now.get(Calendar.MONTH) && x.get(Calendar.DAY_OF_MONTH) == day
                }
                if (day == now.get(Calendar.DAY_OF_MONTH)) {
                    v.setTextColor(id, Color.WHITE)
                    v.setInt(id, "setBackgroundResource", R.drawable.today_bg)
                } else {
                    v.setTextColor(id, if (has) acc else ink)
                    v.setInt(id, "setBackgroundResource", 0)
                }
            } else {
                v.setTextViewText(id, "")
                v.setInt(id, "setBackgroundResource", 0)
            }
        }
    }
}

class QuickWidget : BaseWidget() {
    override val layout: Int get() = R.layout.widget_quick

    override fun fill(c: Context, v: RemoteViews) {
        val a = Intent(c, MainActivity::class.java).putExtra("open", "note")
        val b = Intent(c, MainActivity::class.java).putExtra("open", "reminder")
        val f = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        v.setOnClickPendingIntent(R.id.q_note, PendingIntent.getActivity(c, 10, a, f))
        v.setOnClickPendingIntent(R.id.q_rem, PendingIntent.getActivity(c, 11, b, f))
    }
}
