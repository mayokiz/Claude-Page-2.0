package com.claudepage.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Note(val id: Long, var title: String, var body: String, var updated: Long)
data class Reminder(val id: Long, var text: String, var time: Long, var done: Boolean, var repeat: Int)
data class Server(val id: Long, var name: String, var url: String, var token: String)

fun fmt(t: Long): String = SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault()).format(Date(t))

fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance()
    x.timeInMillis = a
    val y = Calendar.getInstance()
    y.timeInMillis = b
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

fun dayKey(d: Date): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(d)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("claude_page", Context.MODE_PRIVATE)

    fun notes(c: Context): MutableList<Note> {
        val out = mutableListOf<Note>()
        val a = JSONArray(p(c).getString("notes", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Note(o.getLong("id"), o.getString("title"), o.getString("body"), o.getLong("updated")))
        }
        return out
    }

    fun saveNotes(c: Context, l: List<Note>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("updated", it.updated)) }
        p(c).edit().putString("notes", a.toString()).apply()
        Widgets.refresh(c)
    }

    fun reminders(c: Context): MutableList<Reminder> {
        val out = mutableListOf<Reminder>()
        val a = JSONArray(p(c).getString("reminders", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Reminder(o.getLong("id"), o.getString("text"), o.getLong("time"), o.getBoolean("done"), o.optInt("repeat", 0)))
        }
        return out
    }

    fun saveReminders(c: Context, l: List<Reminder>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("text", it.text).put("time", it.time).put("done", it.done).put("repeat", it.repeat)) }
        p(c).edit().putString("reminders", a.toString()).apply()
        Widgets.refresh(c)
    }

    fun toggle(c: Context, id: Long) {
        val l = reminders(c)
        val r = l.find { it.id == id } ?: return
        if (r.done) {
            r.done = false
            Alarms.set(c, r)
        } else if (r.repeat > 0) {
            Alarms.cancel(c, r)
            Alarms.bump(r)
            Alarms.set(c, r)
        } else {
            r.done = true
            Alarms.cancel(c, r)
        }
        saveReminders(c, l)
    }

    fun finish(c: Context, id: Long) {
        val l = reminders(c)
        val r = l.find { it.id == id } ?: return
        if (r.done) return
        if (r.repeat > 0) {
            Alarms.cancel(c, r)
            Alarms.bump(r)
            Alarms.set(c, r)
        } else {
            r.done = true
            Alarms.cancel(c, r)
        }
        saveReminders(c, l)
    }

    fun snooze(c: Context, id: Long) {
        val l = reminders(c)
        val r = l.find { it.id == id } ?: return
        r.time = System.currentTimeMillis() + 10 * 60000L
        r.done = false
        Alarms.set(c, r)
        saveReminders(c, l)
    }

    private fun moodMap(c: Context): JSONObject = JSONObject(p(c).getString("mood", "{}"))
    fun mood(c: Context, key: String): Int = moodMap(c).optInt(key, 0)
    fun setMood(c: Context, key: String, v: Int) {
        p(c).edit().putString("mood", moodMap(c).put(key, v).toString()).apply()
    }

    fun servers(c: Context): MutableList<Server> {
        val out = mutableListOf<Server>()
        val a = JSONArray(p(c).getString("servers", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Server(o.getLong("id"), o.getString("name"), o.getString("url"), o.optString("token", "")))
        }
        return out
    }

    fun saveServers(c: Context, l: List<Server>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url).put("token", it.token)) }
        p(c).edit().putString("servers", a.toString()).apply()
    }
}

object Alarms {
    private fun pi(c: Context, r: Reminder): PendingIntent {
        val i = Intent(c, ReminderReceiver::class.java).putExtra("text", r.text).putExtra("id", r.id)
        return PendingIntent.getBroadcast(c, (r.id and 0x7fffffffL).toInt(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun set(c: Context, r: Reminder) {
        if (r.done || r.time <= System.currentTimeMillis()) return
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(r.time, show), pi(c, r))
    }

    fun cancel(c: Context, r: Reminder) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(c, r))
    }

    private fun step(r: Reminder) {
        val cal = Calendar.getInstance()
        cal.timeInMillis = r.time
        cal.add(Calendar.DAY_OF_YEAR, if (r.repeat == 1) 1 else 7)
        r.time = cal.timeInMillis
    }

    fun advance(r: Reminder) {
        if (r.repeat == 0) return
        while (r.time <= System.currentTimeMillis()) step(r)
    }

    fun bump(r: Reminder) {
        if (r.repeat == 0) return
        step(r)
        advance(r)
    }
}

object Notifier {
    const val CH = "reminders"

    fun channel(c: Context) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Reminders", NotificationManager.IMPORTANCE_HIGH))
    }

    fun post(c: Context, title: String, text: String, id: Int) {
        channel(c)
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_burst)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}

object Widgets {
    fun refresh(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        listOf<BaseWidget>(NextWidget(), NoteWidget(), AgendaWidget(), CalendarWidget(), QuickWidget()).forEach { w ->
            val ids = m.getAppWidgetIds(ComponentName(c, w.javaClass))
            if (ids.isNotEmpty()) w.onUpdate(c, m, ids)
        }
    }
}
