package com.claudepage.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

class Ring(c: Context) : View(c) {
    var frac = 1f
    var text = ""
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val d = resources.displayMetrics.density
        val sw = d * 12f
        val r = RectF(sw, sw, width - sw, height - sw)
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.strokeCap = Paint.Cap.ROUND
        p.color = P.line
        canvas.drawArc(r, 0f, 360f, false, p)
        p.color = P.accent
        canvas.drawArc(r, -90f, 360f * frac, false, p)
        p.style = Paint.Style.FILL
        p.color = P.ink
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.SERIF
        p.textSize = d * 50f
        canvas.drawText(text, width / 2f, height / 2f - (p.descent() + p.ascent()) / 2f, p)
    }
}

class Bars(c: Context) : View(c) {
    var values = IntArray(7)
    var labels = listOf<String>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val d = resources.displayMetrics.density
        val n = values.size
        val gap = 10f * d
        val bw = (width - gap * (n - 1)) / n
        val ch = height - 22f * d
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.SERIF
        p.textSize = 11f * d
        for (i in 0 until n) {
            val x = i * (bw + gap)
            val h = if (values[i] > 0) ch * values[i] / 10f else 4f * d
            p.color = if (values[i] > 0) P.accent else P.line
            canvas.drawRoundRect(RectF(x, ch - h, x + bw, ch), 8f * d, 8f * d, p)
            p.color = P.muted
            if (i < labels.size) canvas.drawText(labels[i], x + bw / 2f, height - 4f * d, p)
        }
    }
}
