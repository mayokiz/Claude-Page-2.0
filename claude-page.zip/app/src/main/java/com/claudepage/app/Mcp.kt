package com.claudepage.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class McpTool(val name: String, val desc: String, val schema: String)

class McpClient(private val url: String, private val token: String) {
    private var session: String? = null
    private var nextId = 1

    private fun post(body: JSONObject, expectReply: Boolean): JSONObject? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", "application/json, text/event-stream")
        if (token.isNotBlank()) c.setRequestProperty("Authorization", "Bearer " + token)
        val s = session
        if (s != null) c.setRequestProperty("Mcp-Session-Id", s)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val sid = c.getHeaderField("Mcp-Session-Id")
        if (sid != null) session = sid
        val stream = if (code < 400) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.readText() ?: ""
        if (code >= 400) throw Exception("HTTP " + code + " " + text.take(200))
        if (!expectReply || text.isBlank()) return null
        val ct = c.contentType ?: ""
        if (ct.contains("event-stream")) {
            var found: JSONObject? = null
            for (line in text.lines()) {
                if (line.startsWith("data:")) {
                    try {
                        val o = JSONObject(line.substring(5).trim())
                        if (o.has("result") || o.has("error")) found = o
                    } catch (e: Exception) {
                    }
                }
            }
            return found
        }
        return JSONObject(text)
    }

    private fun rpc(method: String, params: JSONObject): JSONObject {
        val id = nextId
        nextId = nextId + 1
        val req = JSONObject().put("jsonrpc", "2.0").put("id", id).put("method", method).put("params", params)
        val r = post(req, true) ?: throw Exception("Empty reply from server")
        if (r.has("error")) throw Exception(r.getJSONObject("error").optString("message", "Server error"))
        return r.getJSONObject("result")
    }

    fun connect(): List<McpTool> {
        val init = JSONObject()
            .put("protocolVersion", "2025-03-26")
            .put("capabilities", JSONObject())
            .put("clientInfo", JSONObject().put("name", "Claude Page").put("version", "2.0"))
        rpc("initialize", init)
        post(JSONObject().put("jsonrpc", "2.0").put("method", "notifications/initialized"), false)
        val arr = rpc("tools/list", JSONObject()).optJSONArray("tools") ?: JSONArray()
        val out = mutableListOf<McpTool>()
        for (i in 0 until arr.length()) {
            val t = arr.getJSONObject(i)
            out.add(McpTool(t.getString("name"), t.optString("description", ""), t.optJSONObject("inputSchema")?.toString() ?: "{}"))
        }
        return out
    }

    fun call(name: String, args: JSONObject): String {
        val res = rpc("tools/call", JSONObject().put("name", name).put("arguments", args))
        val content = res.optJSONArray("content") ?: return res.toString(2)
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val item = content.getJSONObject(i)
            if (item.optString("type") == "text") sb.append(item.optString("text")).append("\n")
        }
        return if (sb.isEmpty()) res.toString(2) else sb.toString().trim()
    }
}
