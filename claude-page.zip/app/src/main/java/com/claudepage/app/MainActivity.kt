package com.claudepage.app

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var stage: FrameLayout
    private lateinit var body: FrameLayout
    private val tabNames = listOf("Home", "Notes", "Reminders", "Calendar", "Focus")
    private val tabViews = mutableListOf<TextView>()
    private var tab = 0
    private val stack = mutableListOf<View>()
    private val closers = HashMap<View, () -> Unit>()
    private val handler = Handler(Looper.getMainLooper())
    private var cm: Calendar = Calendar.getInstance()
    private var cs: Calendar = Calendar.getInstance()
    private var fMin = 25
    private var fLeft = 25 * 60
    private var fRun = false
    private var fUi: (() -> Unit)? = null

    private val ticker = object : Runnable {
        override fun run() {
            if (fRun) {
                fLeft = fLeft - 1
                if (fLeft <= 0) {
                    fRun = false
                    fLeft = fMin * 60
                    Notifier.post(this@MainActivity, "Focus session complete", "Nice work. Take a short break.", 4242)
                }
                fUi?.invoke()
                if (fRun) handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        P.init(this)
        window.statusBarColor = P.bg
        window.navigationBarColor = P.bg
        window.decorView.systemUiVisibility =
            if (P.dark) 0 else (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        Notifier.channel(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)

        stage = FrameLayout(this)
        stage.setBackgroundColor(P.bg)
        val shell = LinearLayout(this)
        shell.orientation = LinearLayout.VERTICAL

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(24), dp(16), dp(18), dp(4))
        head.addView(label("Claude Page", 26f, P.ink), LinearLayout.LayoutParams(0, -2, 1f))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_burst)
        logo.setPadding(dp(5), dp(5), dp(5), dp(5))
        logo.setOnClickListener { push(settingsView()) }
        head.addView(logo, LinearLayout.LayoutParams(dp(46), dp(46)))
        shell.addView(head)

        body = FrameLayout(this)
        shell.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        val bar = LinearLayout(this)
        bar.setPadding(dp(8), dp(6), dp(8), dp(10))
        tabNames.forEachIndexed { i, n ->
            val t = label(n, 12f, P.muted)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(11), 0, dp(11))
            t.setOnClickListener { show(i) }
            tabViews.add(t)
            val lpar = LinearLayout.LayoutParams(0, -2, 1f)
            lpar.leftMargin = dp(2)
            lpar.rightMargin = dp(2)
            bar.addView(t, lpar)
        }
        shell.addView(bar)
        stage.addView(shell, FrameLayout.LayoutParams(-1, -1))
        setContentView(stage)
        show(0)
        if (b == null) {
            splash()
            stage.post { handleIntent(intent) }
        }
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        handleIntent(i)
    }

    override fun onPause() {
        super.onPause()
        stack.forEach { closers[it]?.invoke() }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(ticker)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (stack.isNotEmpty()) pop() else super.onBackPressed()
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT)
            if (t != null) {
                val l = Store.notes(this)
                val now = System.currentTimeMillis()
                l.add(Note(now, i.getStringExtra(Intent.EXTRA_SUBJECT) ?: "Shared", t, now))
                Store.saveNotes(this, l)
                show(1)
            }
        }
        val open = i.getStringExtra("open")
        if (open == "note") push(noteEditor(null))
        if (open == "reminder") push(reminderEditor(null, null))
        i.removeExtra("open")
    }

    // ---------- chrome

    private fun splash() {
        val s = FrameLayout(this)
        s.setBackgroundColor(P.bg)
        s.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_burst)
        col.addView(logo, LinearLayout.LayoutParams(dp(96), dp(96)))
        val t = label("Claude Page", 30f, P.ink)
        t.alpha = 0f
        t.translationY = dp(10).toFloat()
        col.addView(t, lp(top = dp(14)))
        t.gravity = Gravity.CENTER
        s.addView(col, FrameLayout.LayoutParams(-1, -1))
        stage.addView(s, FrameLayout.LayoutParams(-1, -1))
        logo.scaleX = 0.4f
        logo.scaleY = 0.4f
        logo.rotation = -70f
        logo.alpha = 0f
        logo.animate().scaleX(1f).scaleY(1f).rotation(0f).alpha(1f).setDuration(700)
            .setInterpolator(OvershootInterpolator(1.2f)).start()
        t.animate().alpha(1f).translationY(0f).setStartDelay(350).setDuration(500).start()
        s.animate().alpha(0f).setStartDelay(1300).setDuration(450).withEndAction { stage.removeView(s) }.start()
    }

    private fun show(i: Int) {
        tab = i
        tabViews.forEachIndexed { j, t ->
            t.setTextColor(if (j == i) P.accent else P.muted)
            t.background = if (j == i) shape(P.surface, 18) else null
        }
        body.removeAllViews()
        val v = when (i) {
            0 -> homeView()
            1 -> notesView()
            2 -> remindersView()
            3 -> calendarView()
            else -> focusView()
        }
        v.alpha = 0f
        v.translationY = dp(16).toFloat()
        body.addView(v)
        v.animate().alpha(1f).translationY(0f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun push(v: View) {
        v.setBackgroundColor(P.bg)
        v.isClickable = true
        stage.addView(v, FrameLayout.LayoutParams(-1, -1))
        stack.add(v)
        val w = if (stage.width > 0) stage.width else resources.displayMetrics.widthPixels
        v.translationX = w.toFloat()
        v.animate().translationX(0f).setDuration(300).setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    private fun pop() {
        if (stack.isEmpty()) return
        val v = stack.removeAt(stack.size - 1)
        closers.remove(v)?.invoke()
        hideKeyboard()
        val w = if (stage.width > 0) stage.width else resources.displayMetrics.widthPixels
        v.animate().translationX(w.toFloat()).setDuration(240).withEndAction {
            stage.removeView(v)
            if (stack.isEmpty()) show(tab)
        }.start()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(stage.windowToken, 0)
    }

    private fun page(views: List<View>): ScrollView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(6), dp(22), dp(28))
        views.forEach { col.addView(it, lp(top = dp(12))) }
        val s = ScrollView(this)
        s.isVerticalScrollBarEnabled = false
        s.addView(col)
        return s
    }

    private fun screen(rightLabel: String?, onRight: (() -> Unit)?, items: List<View>): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(14), dp(14), dp(14), dp(4))
        val back = label("\u2039  Back", 17f, P.accent)
        back.setPadding(dp(8), dp(8), dp(8), dp(8))
        back.setOnClickListener { pop() }
        bar.addView(back)
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        if (rightLabel != null) {
            val rt = label(rightLabel, 17f, P.accent)
            rt.setPadding(dp(8), dp(8), dp(8), dp(8))
            rt.setOnClickListener { if (onRight != null) onRight() }
            bar.addView(rt)
        }
        col.addView(bar)
        col.addView(page(items), LinearLayout.LayoutParams(-1, 0, 1f))
        return col
    }

    private fun field(hint: String, text: String, size: Float): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(text)
        e.textSize = size
        e.typeface = Typeface.SERIF
        e.setTextColor(P.ink)
        e.setHintTextColor(P.muted)
        e.background = null
        e.setPadding(0, dp(6), 0, dp(6))
        e.highlightColor = (P.accent and 0x00FFFFFF) or 0x55000000
        return e
    }

    private fun cl(s: String, size: Float, color: Int): TextView {
        val t = label(s, size, color)
        t.gravity = Gravity.CENTER
        return t
    }

    private fun chipRow(opts: List<String>, sel: Int, onSelect: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        val chips = mutableListOf<TextView>()
        fun paint(s: Int) {
            chips.forEachIndexed { i, c ->
                c.setTextColor(if (i == s) 0xFFFFFFFF.toInt() else P.ink)
                c.background = if (i == s) shape(P.accent, 22) else shape(P.surface, 22, P.line)
            }
        }
        opts.forEachIndexed { i, o ->
            val c = label(o, 14f, P.ink)
            c.gravity = Gravity.CENTER
            c.setPadding(dp(14), dp(10), dp(14), dp(10))
            c.setOnClickListener {
                paint(i)
                onSelect(i)
            }
            chips.add(c)
            val lpar = LinearLayout.LayoutParams(-2, -2)
            lpar.rightMargin = dp(8)
            row.addView(c, lpar)
        }
        paint(sel)
        return row
    }

    private fun slider(max: Int, prog: Int, onChange: (Int) -> Unit, onDone: (Int) -> Unit = {}): SeekBar {
        val s = SeekBar(this)
        s.max = max
        s.progress = prog
        s.progressTintList = ColorStateList.valueOf(P.accent)
        s.thumbTintList = ColorStateList.valueOf(P.accent)
        s.progressBackgroundTintList = ColorStateList.valueOf(P.line)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                onDone(seekBar?.progress ?: 0)
            }
        })
        return s
    }

    // ---------- home

    private fun infoCard(title: String, big: String, small: String, hot: Boolean, onClick: () -> Unit): View {
        val c = card()
        c.minimumHeight = dp(160)
        if (hot) c.background = shape(P.accent, 22)
        val fg = if (hot) 0xFFFFFFFF.toInt() else P.ink
        val fg2 = if (hot) 0xCCFFFFFF.toInt() else P.muted
        c.addView(label(title, 13f, fg2))
        val b = label(big, 24f, fg)
        b.maxLines = 3
        b.ellipsize = TextUtils.TruncateAt.END
        c.addView(b, lp(top = dp(12)))
        c.addView(label(small, 13f, fg2), lp(top = dp(10)))
        c.setOnClickListener { onClick() }
        return c
    }

    private fun carousel(cards: List<View>): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        val w = (resources.displayMetrics.widthPixels * 0.70f).toInt()
        val gap = dp(12)
        cards.forEach {
            val lpar = LinearLayout.LayoutParams(w, -2)
            lpar.rightMargin = gap
            row.addView(it, lpar)
        }
        hs.addView(row)
        hs.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                v.postDelayed({
                    val step = (w + gap).toFloat()
                    val idx = Math.round(hs.scrollX / step)
                    hs.smoothScrollTo((idx * step).toInt(), 0)
                }, 140)
            }
            false
        }
        return hs
    }

    private fun weekStrip(): View {
        val row = LinearLayout(this)
        val rs = Store.reminders(this).filter { !it.done }
        for (i in 0 until 7) {
            val d = Calendar.getInstance()
            d.add(Calendar.DAY_OF_YEAR, i)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            col.setPadding(0, dp(12), 0, dp(12))
            col.background = if (i == 0) shape(P.accent, 18) else shape(P.surface, 18, P.line)
            val fg = if (i == 0) 0xFFFFFFFF.toInt() else P.ink
            val fg2 = if (i == 0) 0xCCFFFFFF.toInt() else P.muted
            col.addView(cl(SimpleDateFormat("EEE", Locale.getDefault()).format(d.time).take(3), 11f, fg2))
            col.addView(cl(d.get(Calendar.DAY_OF_MONTH).toString(), 18f, fg), lp(top = dp(2)))
            val has = rs.any { sameDay(it.time, d.timeInMillis) }
            val dot = View(this)
            dot.background = oval(if (has) (if (i == 0) 0xFFFFFFFF.toInt() else P.accent) else 0)
            val dl = LinearLayout.LayoutParams(dp(5), dp(5))
            dl.topMargin = dp(5)
            col.addView(dot, dl)
            col.setOnClickListener {
                cm = d.clone() as Calendar
                cs = d.clone() as Calendar
                show(3)
            }
            val lpar = LinearLayout.LayoutParams(0, -2, 1f)
            lpar.rightMargin = if (i < 6) dp(6) else 0
            row.addView(col, lpar)
        }
        return row
    }

    private fun homeView(): View {
        val now = System.currentTimeMillis()
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val hello = if (hr < 5) "Still up?" else if (hr < 12) "Good morning" else if (hr < 18) "Good afternoon" else "Good evening"
        val rs = Store.reminders(this).filter { !it.done }
        val next = rs.filter { it.time > now }.minByOrNull { it.time }
        val todayN = rs.filter { sameDay(it.time, now) }.size
        val overdue = rs.filter { it.time < now }.size
        val note = Store.notes(this).maxByOrNull { it.updated }
        val mood = Store.mood(this, dayKey(Date()))
        val items = mutableListOf<View>()
        items.add(label(hello, 36f, P.ink))
        items.add(label(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 16f, P.muted))
        val cards = mutableListOf<View>()
        cards.add(infoCard("NEXT UP", next?.text ?: "All clear", if (next != null) fmt(next.time) else "Nothing coming up", true) { show(2) })
        cards.add(infoCard("TODAY", if (todayN == 0) "Free day" else todayN.toString() + (if (todayN == 1) " reminder" else " reminders"),
            if (overdue > 0) overdue.toString() + " overdue" else "Nothing overdue", false) { show(2) })
        cards.add(infoCard("LATEST NOTE", note?.title?.ifBlank { "Untitled" } ?: "No notes yet",
            if (note != null) fmt(note.updated) else "Tap to write one", false) { if (note != null) push(noteEditor(note)) else push(noteEditor(null)) })
        cards.add(infoCard("MOOD", if (mood > 0) moodWord(mood) else "Not logged", "Set it on the Focus page", false) { show(4) })
        items.add(carousel(cards))
        items.add(label("THIS WEEK", 13f, P.muted))
        items.add(weekStrip())
        val row = LinearLayout(this)
        val a = button("New note") { push(noteEditor(null)) }
        val b = ghost("New reminder") { push(reminderEditor(null, null)) }
        val la = LinearLayout.LayoutParams(0, -2, 1f)
        la.rightMargin = dp(8)
        row.addView(a, la)
        row.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        items.add(row)
        items.add(ghost("Settings and connections") { push(settingsView()) })
        return page(items)
    }

    // ---------- notes

    private fun notesView(): View {
        val items = mutableListOf<View>()
        items.add(label("Notes", 34f, P.ink))
        items.add(button("New note") { push(noteEditor(null)) })
        val list = Store.notes(this).sortedByDescending { it.updated }
        list.forEach { n ->
            val c = card()
            c.addView(label(n.title.ifBlank { "Untitled" }, 20f, P.ink))
            if (n.body.isNotBlank()) {
                val bd = label(n.body, 15f, P.muted)
                bd.maxLines = 2
                bd.ellipsize = TextUtils.TruncateAt.END
                c.addView(bd, lp(top = dp(6)))
            }
            c.addView(label(fmt(n.updated), 12f, P.muted), lp(top = dp(10)))
            c.setOnClickListener { push(noteEditor(n)) }
            items.add(c)
        }
        if (list.isEmpty()) items.add(label("No notes yet. Tap New note to start.", 16f, P.muted))
        return page(items)
    }

    private fun noteEditor(n: Note?): View {
        var cur: Note? = n
        var gone = false
        val t = field("Title", n?.title ?: "", 28f)
        val b = field("Start writing...", n?.body ?: "", 17f)
        b.minLines = 14
        b.gravity = Gravity.TOP
        b.setLineSpacing(0f, 1.15f)
        val stamp = label(if (n == null) "New note" else "Edited " + fmt(n.updated), 13f, P.muted)
        fun save() {
            if (gone) return
            val ti = t.text.toString().trim()
            val bo = b.text.toString().trim()
            val l = Store.notes(this)
            val c = cur
            if (c == null) {
                if (ti.isEmpty() && bo.isEmpty()) return
                val now = System.currentTimeMillis()
                val nn = Note(now, ti, bo, now)
                l.add(nn)
                cur = nn
            } else {
                val ex = l.find { it.id == c.id } ?: return
                if (ex.title == ti && ex.body == bo) return
                ex.title = ti
                ex.body = bo
                ex.updated = System.currentTimeMillis()
            }
            Store.saveNotes(this, l)
        }
        val del: () -> Unit = {
            val c = cur
            if (c != null) Store.saveNotes(this, Store.notes(this).filter { it.id != c.id })
            gone = true
            pop()
        }
        val v = screen(if (n != null) "Delete" else null, del, listOf(stamp, t, b))
        closers[v] = { save() }
        if (n == null) {
            t.requestFocus()
            handler.postDelayed({
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(t, 0)
            }, 380)
        }
        return v
    }

    // ---------- reminders

    private fun remindersView(): View {
        val now = System.currentTimeMillis()
        val all = Store.reminders(this).sortedBy { it.time }
        val items = mutableListOf<View>()
        items.add(label("Reminders", 34f, P.ink))
        items.add(button("New reminder") { push(reminderEditor(null, null)) })
        val over = all.filter { !it.done && it.time < now }
        val today = all.filter { !it.done && it.time >= now && sameDay(it.time, now) }
        val later = all.filter { !it.done && it.time >= now && !sameDay(it.time, now) }
        val done = all.filter { it.done }.takeLast(5)
        fun sec(title: String, l: List<Reminder>, color: Int) {
            if (l.isNotEmpty()) {
                items.add(label(title, 13f, color))
                l.forEach { items.add(reminderRow(it)) }
            }
        }
        sec("OVERDUE", over, P.accent)
        sec("TODAY", today, P.muted)
        sec("UPCOMING", later, P.muted)
        sec("DONE", done, P.muted)
        if (all.isEmpty()) items.add(label("Nothing here yet. Add your first reminder.", 16f, P.muted))
        return page(items)
    }

    private fun reminderRow(r: Reminder): View {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(14), dp(16), dp(14))
        row.background = shape(P.surface, 20, P.line)
        val circ = label(if (r.done) "\u2713" else "", 16f, 0xFFFFFFFF.toInt())
        circ.gravity = Gravity.CENTER
        circ.background = if (r.done) oval(P.accent) else oval(0, P.accent)
        circ.setOnClickListener {
            Store.toggle(this, r.id)
            show(tab)
        }
        row.addView(circ, LinearLayout.LayoutParams(dp(32), dp(32)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val tv = label(r.text, 17f, if (r.done) P.muted else P.ink)
        if (r.done) tv.paintFlags = tv.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        col.addView(tv)
        val rep = if (r.repeat == 1) "  \u00B7  Daily" else if (r.repeat == 2) "  \u00B7  Weekly" else ""
        val late = !r.done && r.time < System.currentTimeMillis()
        col.addView(label(fmt(r.time) + rep, 13f, if (late) P.accent else P.muted), lp(top = dp(2)))
        val cl2 = LinearLayout.LayoutParams(0, -2, 1f)
        cl2.leftMargin = dp(14)
        row.addView(col, cl2)
        row.setOnClickListener { push(reminderEditor(r, null)) }
        return row
    }

    private fun reminderEditor(r: Reminder?, pre: Long?): View {
        val cal = Calendar.getInstance()
        if (r != null) {
            cal.timeInMillis = r.time
        } else if (pre != null) {
            cal.timeInMillis = pre
        } else {
            cal.add(Calendar.HOUR_OF_DAY, 1)
            cal.set(Calendar.MINUTE, 0)
        }
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        var repeat = r?.repeat ?: 0
        val what = field("What should I remind you about?", r?.text ?: "", 22f)
        val whatCard = card()
        whatCard.addView(label("Reminder", 13f, P.muted))
        whatCard.addView(what)
        val dateTv = label("", 20f, P.ink)
        val timeTv = label("", 20f, P.ink)
        fun refresh() {
            dateTv.text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(cal.time)
            timeTv.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(cal.time)
        }
        refresh()
        val dateCard = card()
        dateCard.addView(label("Date", 13f, P.muted))
        dateCard.addView(dateTv, lp(top = dp(4)))
        dateCard.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                cal.set(y, m, d)
                refresh()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        val timeCard = card()
        timeCard.addView(label("Time", 13f, P.muted))
        timeCard.addView(timeTv, lp(top = dp(4)))
        timeCard.setOnClickListener {
            TimePickerDialog(this, { _, h, mi ->
                cal.set(Calendar.HOUR_OF_DAY, h)
                cal.set(Calendar.MINUTE, mi)
                refresh()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }
        val presets = chipRow(listOf("In 1 hour", "This evening", "Tomorrow 9:00"), -1) { i ->
            val n = Calendar.getInstance()
            if (i == 0) {
                n.add(Calendar.HOUR_OF_DAY, 1)
            } else if (i == 1) {
                n.set(Calendar.HOUR_OF_DAY, 20)
                n.set(Calendar.MINUTE, 0)
                if (n.timeInMillis < System.currentTimeMillis()) n.add(Calendar.DAY_OF_YEAR, 1)
            } else {
                n.add(Calendar.DAY_OF_YEAR, 1)
                n.set(Calendar.HOUR_OF_DAY, 9)
                n.set(Calendar.MINUTE, 0)
            }
            cal.timeInMillis = n.timeInMillis
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            refresh()
        }
        val repeats = chipRow(listOf("Once", "Every day", "Every week"), repeat) { repeat = it }
        val save = button(if (r == null) "Save reminder" else "Save changes") {
            val text = what.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, "Write what to remind you about", Toast.LENGTH_SHORT).show()
            } else if (cal.timeInMillis <= System.currentTimeMillis() && repeat == 0) {
                Toast.makeText(this, "Pick a time in the future", Toast.LENGTH_SHORT).show()
            } else {
                val l = Store.reminders(this)
                val ex = if (r == null) null else l.find { it.id == r.id }
                if (ex != null) {
                    Alarms.cancel(this, ex)
                    ex.text = text
                    ex.time = cal.timeInMillis
                    ex.repeat = repeat
                    ex.done = false
                    Alarms.advance(ex)
                    Alarms.set(this, ex)
                } else {
                    val nr = Reminder(System.currentTimeMillis(), text, cal.timeInMillis, false, repeat)
                    Alarms.advance(nr)
                    l.add(nr)
                    Alarms.set(this, nr)
                }
                Store.saveReminders(this, l)
                pop()
            }
        }
        val del: () -> Unit = {
            if (r != null) {
                Alarms.cancel(this, r)
                Store.saveReminders(this, Store.reminders(this).filter { it.id != r.id })
            }
            pop()
        }
        val items = mutableListOf<View>()
        items.add(label(if (r == null) "New reminder" else "Edit reminder", 32f, P.ink))
        items.add(whatCard)
        items.add(dateCard)
        items.add(timeCard)
        items.add(label("QUICK PICKS", 13f, P.muted))
        items.add(presets)
        items.add(label("REPEAT", 13f, P.muted))
        items.add(repeats)
        items.add(save)
        val v = screen(if (r != null) "Delete" else null, del, items)
        if (r == null && pre == null) {
            what.requestFocus()
            handler.postDelayed({
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(what, 0)
            }, 380)
        }
        return v
    }

    // ---------- calendar

    private fun presetFor(d: Calendar): Long {
        val x = d.clone() as Calendar
        x.set(Calendar.HOUR_OF_DAY, 9)
        x.set(Calendar.MINUTE, 0)
        x.set(Calendar.SECOND, 0)
        if (x.timeInMillis <= System.currentTimeMillis() && sameDay(x.timeInMillis, System.currentTimeMillis())) {
            val n = Calendar.getInstance()
            n.add(Calendar.HOUR_OF_DAY, 1)
            n.set(Calendar.MINUTE, 0)
            return n.timeInMillis
        }
        return x.timeInMillis
    }

    private fun calendarView(): View {
        val items = mutableListOf<View>()
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val prev = label("\u2039", 34f, P.accent)
        prev.setPadding(dp(14), 0, dp(14), 0)
        prev.setOnClickListener {
            cm.add(Calendar.MONTH, -1)
            show(3)
        }
        val nxt = label("\u203A", 34f, P.accent)
        nxt.setPadding(dp(14), 0, dp(14), 0)
        nxt.setOnClickListener {
            cm.add(Calendar.MONTH, 1)
            show(3)
        }
        head.addView(label(SimpleDateFormat("LLLL yyyy", Locale.getDefault()).format(cm.time), 28f, P.ink), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(prev)
        head.addView(nxt)
        items.add(head)

        val first = cm.clone() as Calendar
        first.set(Calendar.DAY_OF_MONTH, 1)
        val offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val days = first.getActualMaximum(Calendar.DAY_OF_MONTH)
        val rs = Store.reminders(this).filter { !it.done }
        val today = Calendar.getInstance()
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        val wd = LinearLayout(this)
        for (x in listOf("M", "T", "W", "T", "F", "S", "S")) wd.addView(cl(x, 12f, P.muted), LinearLayout.LayoutParams(0, -2, 1f))
        grid.addView(wd)
        for (row in 0 until 6) {
            if (row * 7 - offset + 1 > days) break
            val line = LinearLayout(this)
            for (col in 0 until 7) {
                val day = row * 7 + col - offset + 1
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER
                if (day in 1..days) {
                    val d = cm.clone() as Calendar
                    d.set(Calendar.DAY_OF_MONTH, day)
                    val isToday = sameDay(d.timeInMillis, today.timeInMillis)
                    val isSel = sameDay(d.timeInMillis, cs.timeInMillis)
                    val t = cl(day.toString(), 15f, if (isToday) 0xFFFFFFFF.toInt() else P.ink)
                    if (isToday) t.background = oval(P.accent) else if (isSel) t.background = oval(0, P.accent)
                    cell.addView(t, LinearLayout.LayoutParams(dp(36), dp(36)))
                    val has = rs.any { sameDay(it.time, d.timeInMillis) }
                    val dot = View(this)
                    dot.background = oval(if (has) P.accent else 0)
                    val dl = LinearLayout.LayoutParams(dp(5), dp(5))
                    dl.topMargin = dp(1)
                    cell.addView(dot, dl)
                    cell.setOnClickListener {
                        cs = d.clone() as Calendar
                        show(3)
                    }
                }
                line.addView(cell, LinearLayout.LayoutParams(0, dp(50), 1f))
            }
            grid.addView(line)
        }
        items.add(grid)
        items.add(label(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(cs.time), 20f, P.ink))
        val dayList = rs.filter { sameDay(it.time, cs.timeInMillis) }.sortedBy { it.time }
        if (dayList.isEmpty()) items.add(label("Nothing planned.", 15f, P.muted))
        dayList.forEach { items.add(reminderRow(it)) }
        items.add(button("Add reminder on this day") { push(reminderEditor(null, presetFor(cs))) })
        return page(items)
    }

    // ---------- focus

    private fun moodWord(v: Int): String {
        val w = if (v <= 2) "Drained" else if (v <= 4) "Low" else if (v <= 6) "Steady" else if (v <= 8) "Good" else "Radiant"
        return w + "  \u00B7  " + v + "/10"
    }

    private fun focusView(): View {
        val ring = Ring(this)
        fun upd() {
            ring.frac = fLeft / (fMin * 60f)
            ring.text = String.format("%02d:%02d", fLeft / 60, fLeft % 60)
            ring.invalidate()
        }
        upd()
        val startBtn = button(if (fRun) "Pause" else "Start") {}
        startBtn.setOnClickListener {
            fRun = !fRun
            if (fRun) handler.postDelayed(ticker, 1000) else handler.removeCallbacks(ticker)
            startBtn.text = if (fRun) "Pause" else "Start"
        }
        val resetBtn = ghost("Reset") {
            fRun = false
            handler.removeCallbacks(ticker)
            fLeft = fMin * 60
            startBtn.text = "Start"
            upd()
        }
        fUi = {
            upd()
            startBtn.text = if (fRun) "Pause" else "Start"
        }
        val lenTv = label("Session length  \u00B7  " + fMin + " min", 15f, P.muted)
        val lenSb = slider(85, fMin - 5, { v ->
            if (!fRun) {
                fMin = v + 5
                fLeft = fMin * 60
                lenTv.text = "Session length  \u00B7  " + fMin + " min"
                upd()
            }
        })
        val btnRow = LinearLayout(this)
        val la = LinearLayout.LayoutParams(0, -2, 1f)
        la.rightMargin = dp(8)
        btnRow.addView(startBtn, la)
        btnRow.addView(resetBtn, LinearLayout.LayoutParams(0, -2, 1f))
        val ringWrap = LinearLayout(this)
        ringWrap.gravity = Gravity.CENTER
        ringWrap.addView(ring, LinearLayout.LayoutParams(dp(236), dp(236)))

        val key = dayKey(Date())
        val cur = Store.mood(this, key)
        val moodTv = label(if (cur > 0) moodWord(cur) else "Slide to log today", 22f, P.ink)
        val bars = Bars(this)
        fun loadBars() {
            val vals = IntArray(7)
            val labs = mutableListOf<String>()
            for (i in 0 until 7) {
                val d = Calendar.getInstance()
                d.add(Calendar.DAY_OF_YEAR, i - 6)
                vals[i] = Store.mood(this, dayKey(d.time))
                labs.add(SimpleDateFormat("EEE", Locale.getDefault()).format(d.time).take(2))
            }
            bars.values = vals
            bars.labels = labs
            bars.invalidate()
        }
        loadBars()
        val moodSb = slider(9, if (cur > 0) cur - 1 else 4, { v -> moodTv.text = moodWord(v + 1) }, { v ->
            Store.setMood(this, key, v + 1)
            loadBars()
        })
        val items = mutableListOf<View>()
        items.add(label("Focus", 34f, P.ink))
        items.add(ringWrap)
        items.add(lenTv)
        items.add(lenSb)
        items.add(btnRow)
        items.add(label("MOOD", 13f, P.muted))
        items.add(moodTv)
        items.add(moodSb)
        val barsWrap = LinearLayout(this)
        barsWrap.addView(bars, LinearLayout.LayoutParams(-1, dp(130)))
        items.add(barsWrap)
        return page(items)
    }

    // ---------- settings and MCP

    private fun settingsView(): View {
        val items = mutableListOf<View>()
        items.add(label("Settings", 34f, P.ink))
        items.add(label("APPEARANCE", 13f, P.muted))
        val cur = getSharedPreferences("claude_page", Context.MODE_PRIVATE).getInt("theme", 0)
        items.add(chipRow(listOf("System", "Light", "Dark"), cur) { i ->
            getSharedPreferences("claude_page", Context.MODE_PRIVATE).edit().putInt("theme", i).apply()
            recreate()
        })
        items.add(label("CONNECTIONS", 13f, P.muted))
        items.add(ghost("MCP servers") { push(connectionsView()) })
        items.add(label("NOTIFICATIONS", 13f, P.muted))
        items.add(ghost("Notification settings") {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(i)
        })
        items.add(label("Reminders use the system alarm, so they ring on time even in battery saver. Widgets: long-press your home screen and look for Claude Page.", 14f, P.muted))
        items.add(label("Claude Page 2.0", 13f, P.muted))
        return screen(null, null, items)
    }

    private fun connectionsView(): View {
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        fun rebuild() {
            list.removeAllViews()
            Store.servers(this).forEach { s ->
                val c = card()
                c.addView(label(s.name, 19f, P.ink))
                c.addView(label(s.url, 13f, P.muted), lp(top = dp(2)))
                c.setOnClickListener { push(serverView(s)) }
                list.addView(c, lp(top = dp(10)))
            }
        }
        rebuild()
        val items = mutableListOf<View>()
        items.add(label("Connections", 34f, P.ink))
        items.add(label("Connect to remote MCP servers. Tap a server to see its tools and run them. Servers that need a login through the browser are not supported, only ones that accept a bearer token or none.", 15f, P.muted))
        items.add(button("Add server") { push(serverEditor(null) { rebuild() }) })
        items.add(list)
        return screen(null, null, items)
    }

    private fun serverEditor(s: Server?, onDone: (Boolean) -> Unit): View {
        val name = field("Name", s?.name ?: "", 20f)
        val url = field("https://example.com/mcp", s?.url ?: "", 17f)
        val token = field("Bearer token (optional)", s?.token ?: "", 17f)
        fun boxed(title: String, e: EditText): View {
            val c = card()
            c.addView(label(title, 13f, P.muted))
            c.addView(e)
            return c
        }
        val save = button("Save server") {
            val u = url.text.toString().trim()
            if (!u.startsWith("http")) {
                Toast.makeText(this, "Enter a full URL starting with https://", Toast.LENGTH_SHORT).show()
            } else {
                val l = Store.servers(this)
                val nm = name.text.toString().trim().ifBlank { u }
                val ex = if (s == null) null else l.find { it.id == s.id }
                if (ex != null) {
                    ex.name = nm
                    ex.url = u
                    ex.token = token.text.toString().trim()
                } else {
                    l.add(Server(System.currentTimeMillis(), nm, u, token.text.toString().trim()))
                }
                Store.saveServers(this, l)
                pop()
                onDone(false)
            }
        }
        val del: () -> Unit = {
            if (s != null) Store.saveServers(this, Store.servers(this).filter { it.id != s.id })
            pop()
            onDone(true)
        }
        val items = mutableListOf<View>()
        items.add(label(if (s == null) "Add server" else "Edit server", 32f, P.ink))
        items.add(boxed("Name", name))
        items.add(boxed("Server URL", url))
        items.add(boxed("Token", token))
        items.add(save)
        return screen(if (s != null) "Delete" else null, del, items)
    }

    private fun serverView(s: Server): View {
        val status = label("Connecting...", 15f, P.muted)
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val client = McpClient(s.url, s.token)
        Thread {
            try {
                val tools = client.connect()
                runOnUiThread {
                    status.text = "Connected. " + tools.size + " tools available."
                    tools.forEach { t ->
                        val c = card()
                        c.addView(label(t.name, 18f, P.ink))
                        if (t.desc.isNotBlank()) {
                            val d = label(t.desc, 13f, P.muted)
                            d.maxLines = 3
                            d.ellipsize = TextUtils.TruncateAt.END
                            c.addView(d, lp(top = dp(4)))
                        }
                        c.setOnClickListener { push(toolView(client, t)) }
                        list.addView(c, lp(top = dp(10)))
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Could not connect: " + e.message }
            }
        }.start()
        val items = mutableListOf<View>()
        items.add(label(s.name, 30f, P.ink))
        items.add(status)
        items.add(list)
        return screen("Edit", { push(serverEditor(s) { deleted -> if (deleted) pop() }) }, items)
    }

    private fun toolView(client: McpClient, t: McpTool): View {
        val args = field("{}", "{}", 16f)
        args.minLines = 3
        args.gravity = Gravity.TOP
        val argsCard = card()
        argsCard.addView(label("Arguments (JSON)", 13f, P.muted))
        argsCard.addView(args)
        val out = label("", 15f, P.ink)
        out.setTextIsSelectable(true)
        val run = button("Run tool") {
            val parsed: JSONObject? = try {
                JSONObject(args.text.toString().ifBlank { "{}" })
            } catch (e: Exception) {
                null
            }
            if (parsed == null) {
                Toast.makeText(this, "Arguments must be valid JSON", Toast.LENGTH_SHORT).show()
            } else {
                out.text = "Running..."
                Thread {
                    val res = try {
                        client.call(t.name, parsed)
                    } catch (e: Exception) {
                        "Failed: " + e.message
                    }
                    runOnUiThread { out.text = res }
                }.start()
            }
        }
        val items = mutableListOf<View>()
        items.add(label(t.name, 28f, P.ink))
        if (t.desc.isNotBlank()) items.add(label(t.desc, 15f, P.muted))
        items.add(label("Input: " + t.schema.take(400), 12f, P.muted))
        items.add(argsCard)
        items.add(run)
        items.add(out)
        return screen(null, null, items)
    }
}
