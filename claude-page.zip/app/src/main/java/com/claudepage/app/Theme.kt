package com.claudepage.app

import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.LinearLayout
import android.widget.TextView

object P {
    var dark = false
    val bg: Int get() = if (dark) 0xFF262624.toInt() else 0xFFFAF9F5.toInt()
    val surface: Int get() = if (dark) 0xFF30302E.toInt() else 0xFFF0EEE6.toInt()
    val line: Int get() = if (dark) 0xFF41413E.toInt() else 0xFFE3E0D5.toInt()
    val ink: Int get() = if (dark) 0xFFF5F4ED.toInt() else 0xFF141413.toInt()
    val muted: Int get() = if (dark) 0xFFA8A69C.toInt() else 0xFF6E6D68.toInt()
    val accent: Int get() = 0xFFD97757.toInt()

    fun init(c: Context) {
        val mode = c.getSharedPreferences("claude_page", Context.MODE_PRIVATE).getInt("theme", 0)
        dark = when (mode) {
            1 -> false
            2 -> true
            else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        }
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun lp(w: Int = -1, h: Int = -2, top: Int = 0): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h)
    p.topMargin = top
    return p
}

fun Context.shape(fill: Int, radius: Int, stroke: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = dp(radius).toFloat()
    if (stroke != 0) g.setStroke(dp(1), stroke)
    return g
}

fun Context.oval(fill: Int, stroke: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(fill)
    if (stroke != 0) g.setStroke(dp(2), stroke)
    return g
}

fun Context.label(s: String, size: Float = 15f, color: Int = P.ink): TextView {
    val t = TextView(this)
    t.text = s
    t.textSize = size
    t.setTextColor(color)
    t.typeface = Typeface.SERIF
    return t
}

fun Context.card(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.setPadding(dp(18), dp(16), dp(18), dp(16))
    l.background = shape(P.surface, 20, P.line)
    return l
}

fun Context.button(s: String, onClick: () -> Unit): TextView {
    val t = label(s, 16f, 0xFFFFFFFF.toInt())
    t.gravity = android.view.Gravity.CENTER
    t.setPadding(dp(20), dp(14), dp(20), dp(14))
    t.background = shape(P.accent, 28)
    t.setOnClickListener { onClick() }
    return t
}

fun Context.ghost(s: String, onClick: () -> Unit): TextView {
    val t = label(s, 16f, P.ink)
    t.gravity = android.view.Gravity.CENTER
    t.setPadding(dp(20), dp(14), dp(20), dp(14))
    t.background = shape(P.surface, 28, P.line)
    t.setOnClickListener { onClick() }
    return t
}
